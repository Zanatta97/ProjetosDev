package com.samuel.controledeentradaempresas.ui.dados;

import androidx.lifecycle.ViewModel;

public class DadosViewModel extends ViewModel {

    public DadosViewModel(){

    }
}
