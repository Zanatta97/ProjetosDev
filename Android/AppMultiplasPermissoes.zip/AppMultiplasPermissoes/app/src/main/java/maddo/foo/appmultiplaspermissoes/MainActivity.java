package maddo.foo.appmultiplaspermissoes;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Recomendação
 *
 * Para o melhor entendimento desta aula, é importante você ter
 * entendido as aulas anteriores ou já tem um nível além do
 * iniciante.
 *
 * Este é um projeto que contém apenas o ESQUELETO que deverá
 * ser utilizado por você para acompanhar as próximas aulas
 * relacionadas com permissões múltiplas
 */
public class MainActivity extends AppCompatActivity {

    TextView txtPermissoes;

    public static final int APP_PERMISSIONS_REQUEST_LOCATION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPermissoes = findViewById(R.id.txtPermissoes);

        checarPermissoes();

    }


    private void checarPermissoes() {

        if (Build.VERSION.SDK_INT < 23) {

            txtPermissoes.setText("Ok, todas as permissões ativas.");

            // Acessar as funcionalidades do aplicativo

        } else if (checkAndRequestPermissions()) {

            txtPermissoes.setText("Ok, todas as permissões ativas.");

            // Acessar as funcionalidades do aplicativo

        } else {

            txtPermissoes.setText("OPS! Sem permissões!.");

        }
    }

    private boolean checkAndRequestPermissions() {

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[],
                                           int[] grantResults) {

    }

}
