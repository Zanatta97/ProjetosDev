package foo.maddo.appcidadesbr.adapter;

/**
 * Adapter do Spinner Regiao (Norte, Sul, Centro Oeste, etc)
 */
public class RegiaoAdapter {
}
