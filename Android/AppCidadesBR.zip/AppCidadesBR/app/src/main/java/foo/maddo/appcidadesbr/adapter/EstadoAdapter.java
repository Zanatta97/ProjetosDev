package foo.maddo.appcidadesbr.adapter;

/**
 * Adapter do Spinner Estado (UF)
 */
public class EstadoAdapter {
}
