package foo.maddo.appcidadesbr.adapter;

/**
 * Adapter do Spinner Municipio
 */
public class MunicipioAdapter {
}
