package foo.maddo.appcidadesbr.appapi;

/**
 * Consultar Estados por Regiao no MySQL online
 */
public class EstadoAsyncTask {
}
