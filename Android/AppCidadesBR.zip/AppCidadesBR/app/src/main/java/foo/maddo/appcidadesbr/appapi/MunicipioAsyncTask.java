package foo.maddo.appcidadesbr.appapi;


/**
 * Consultar Municipios por estado no MySQL online
 */
public class MunicipioAsyncTask {
}
