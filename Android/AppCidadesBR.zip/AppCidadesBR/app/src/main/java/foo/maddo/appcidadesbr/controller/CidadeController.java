package foo.maddo.appcidadesbr.controller;

/**
 * Controller da Classe Cidade
 */
public class CidadeController {
}
