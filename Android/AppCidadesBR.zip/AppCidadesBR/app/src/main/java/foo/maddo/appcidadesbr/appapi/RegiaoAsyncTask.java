package foo.maddo.appcidadesbr.appapi;

/**
 * Consultar Regiões no MySQL online
 */
public class RegiaoAsyncTask {
}
