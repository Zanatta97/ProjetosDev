--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_codigopersonagem1_fkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_codigousuario_fkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_codigoraca_fkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_codigoclasse_fkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_armaduraatual_fkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_armaatual_fkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_codigopersonagem_fkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_codigoitem_fkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.racas DROP CONSTRAINT racas_pkey;
ALTER TABLE ONLY public.personagens DROP CONSTRAINT personagens_pkey;
ALTER TABLE ONLY public.itens DROP CONSTRAINT itens_pkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_pkey;
ALTER TABLE ONLY public.classes DROP CONSTRAINT classes_pkey;
ALTER TABLE ONLY public.ataquefeitico DROP CONSTRAINT ataquefeitico_pkey;
DROP TABLE public.usuarios;
DROP TABLE public.racas;
DROP TABLE public.personagens;
DROP TABLE public.itens;
DROP TABLE public.inventario;
DROP TABLE public.classes;
DROP TABLE public.ataquefeitico;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ataquefeitico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ataquefeitico (
    codigo integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(500) NOT NULL,
    tipo integer NOT NULL,
    descricaotipo character varying(100) NOT NULL,
    danobase integer NOT NULL,
    tipobonus integer NOT NULL,
    descricaobonus character varying(100) NOT NULL
);


ALTER TABLE ataquefeitico OWNER TO postgres;

--
-- Name: classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE classes (
    codigoclasse integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(500) NOT NULL,
    forcabase integer NOT NULL,
    destrezabase integer NOT NULL,
    constbase integer NOT NULL,
    inteligenciabase integer NOT NULL,
    sabedoriabase integer NOT NULL,
    carismabase integer NOT NULL,
    pvbase integer NOT NULL
);


ALTER TABLE classes OWNER TO postgres;

--
-- Name: inventario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventario (
    codigo integer NOT NULL,
    codigoitem integer NOT NULL,
    codigopersonagem integer NOT NULL
);


ALTER TABLE inventario OWNER TO postgres;

--
-- Name: itens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE itens (
    codigoitem integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(500) NOT NULL,
    tamanho integer NOT NULL,
    tipo integer NOT NULL,
    raridade integer NOT NULL,
    bonusatributo integer NOT NULL
);


ALTER TABLE itens OWNER TO postgres;

--
-- Name: personagens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE personagens (
    codigopersonagem integer NOT NULL,
    nomepersonagem character varying(100) NOT NULL,
    codigousuario integer NOT NULL,
    codigoraca integer NOT NULL,
    codigoclasse integer NOT NULL,
    nivel integer NOT NULL,
    xp integer NOT NULL,
    pvtotal integer NOT NULL,
    pvatual integer NOT NULL,
    forca integer NOT NULL,
    destreza integer NOT NULL,
    constituicao integer NOT NULL,
    inteligencia integer NOT NULL,
    sabedoria integer NOT NULL,
    carisma integer NOT NULL,
    armaatual integer NOT NULL,
    armaduraatual integer NOT NULL,
    tamanhoinv integer NOT NULL
);


ALTER TABLE personagens OWNER TO postgres;

--
-- Name: racas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE racas (
    codigoraca integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(500) NOT NULL,
    forcabase integer NOT NULL,
    destrezabase integer NOT NULL,
    constbase integer NOT NULL,
    inteligenciabase integer NOT NULL,
    sabedoriabase integer NOT NULL,
    carismabase integer NOT NULL,
    pvbase integer NOT NULL
);


ALTER TABLE racas OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usuarios (
    codigousuario integer NOT NULL,
    login character varying(25) NOT NULL,
    senha character varying(25) NOT NULL,
    codigopersonagem1 integer,
    codigopersonagem2 integer,
    codigopersonagem3 integer,
    ultimologin timestamp without time zone,
    ultimologoff timestamp without time zone,
    horasjogadas time without time zone
);


ALTER TABLE usuarios OWNER TO postgres;

--
-- Data for Name: ataquefeitico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ataquefeitico (codigo, nome, descricao, tipo, descricaotipo, danobase, tipobonus, descricaobonus) FROM stdin;
\.
COPY ataquefeitico (codigo, nome, descricao, tipo, descricaotipo, danobase, tipobonus, descricaobonus) FROM '$$PATH$$/2171.dat';

--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY classes (codigoclasse, nome, descricao, forcabase, destrezabase, constbase, inteligenciabase, sabedoriabase, carismabase, pvbase) FROM stdin;
\.
COPY classes (codigoclasse, nome, descricao, forcabase, destrezabase, constbase, inteligenciabase, sabedoriabase, carismabase, pvbase) FROM '$$PATH$$/2170.dat';

--
-- Data for Name: inventario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventario (codigo, codigoitem, codigopersonagem) FROM stdin;
\.
COPY inventario (codigo, codigoitem, codigopersonagem) FROM '$$PATH$$/2168.dat';

--
-- Data for Name: itens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY itens (codigoitem, nome, descricao, tamanho, tipo, raridade, bonusatributo) FROM stdin;
\.
COPY itens (codigoitem, nome, descricao, tamanho, tipo, raridade, bonusatributo) FROM '$$PATH$$/2172.dat';

--
-- Data for Name: personagens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY personagens (codigopersonagem, nomepersonagem, codigousuario, codigoraca, codigoclasse, nivel, xp, pvtotal, pvatual, forca, destreza, constituicao, inteligencia, sabedoria, carisma, armaatual, armaduraatual, tamanhoinv) FROM stdin;
\.
COPY personagens (codigopersonagem, nomepersonagem, codigousuario, codigoraca, codigoclasse, nivel, xp, pvtotal, pvatual, forca, destreza, constituicao, inteligencia, sabedoria, carisma, armaatual, armaduraatual, tamanhoinv) FROM '$$PATH$$/2167.dat';

--
-- Data for Name: racas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY racas (codigoraca, nome, descricao, forcabase, destrezabase, constbase, inteligenciabase, sabedoriabase, carismabase, pvbase) FROM stdin;
\.
COPY racas (codigoraca, nome, descricao, forcabase, destrezabase, constbase, inteligenciabase, sabedoriabase, carismabase, pvbase) FROM '$$PATH$$/2169.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usuarios (codigousuario, login, senha, codigopersonagem1, codigopersonagem2, codigopersonagem3, ultimologin, ultimologoff, horasjogadas) FROM stdin;
\.
COPY usuarios (codigousuario, login, senha, codigopersonagem1, codigopersonagem2, codigopersonagem3, ultimologin, ultimologoff, horasjogadas) FROM '$$PATH$$/2166.dat';

--
-- Name: ataquefeitico ataquefeitico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ataquefeitico
    ADD CONSTRAINT ataquefeitico_pkey PRIMARY KEY (codigo);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (codigoclasse);


--
-- Name: inventario inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventario
    ADD CONSTRAINT inventario_pkey PRIMARY KEY (codigo);


--
-- Name: itens itens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY itens
    ADD CONSTRAINT itens_pkey PRIMARY KEY (codigoitem);


--
-- Name: personagens personagens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_pkey PRIMARY KEY (codigopersonagem);


--
-- Name: racas racas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY racas
    ADD CONSTRAINT racas_pkey PRIMARY KEY (codigoraca);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (codigousuario);


--
-- Name: inventario inventario_codigoitem_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventario
    ADD CONSTRAINT inventario_codigoitem_fkey FOREIGN KEY (codigoitem) REFERENCES itens(codigoitem);


--
-- Name: inventario inventario_codigopersonagem_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventario
    ADD CONSTRAINT inventario_codigopersonagem_fkey FOREIGN KEY (codigopersonagem) REFERENCES personagens(codigopersonagem);


--
-- Name: personagens personagens_armaatual_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_armaatual_fkey FOREIGN KEY (armaatual) REFERENCES itens(codigoitem);


--
-- Name: personagens personagens_armaduraatual_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_armaduraatual_fkey FOREIGN KEY (armaduraatual) REFERENCES itens(codigoitem);


--
-- Name: personagens personagens_codigoclasse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_codigoclasse_fkey FOREIGN KEY (codigoclasse) REFERENCES classes(codigoclasse);


--
-- Name: personagens personagens_codigoraca_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_codigoraca_fkey FOREIGN KEY (codigoraca) REFERENCES racas(codigoraca);


--
-- Name: personagens personagens_codigousuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personagens
    ADD CONSTRAINT personagens_codigousuario_fkey FOREIGN KEY (codigousuario) REFERENCES usuarios(codigousuario);


--
-- Name: usuarios usuarios_codigopersonagem1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_codigopersonagem1_fkey FOREIGN KEY (codigopersonagem1) REFERENCES personagens(codigopersonagem);


--
-- PostgreSQL database dump complete
--

